# SLCB-ChannelPointsAlerts
Adds the ability to trigger an alert with some combination of image/gif, sfx, and text to speech.
